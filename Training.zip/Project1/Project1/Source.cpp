#include <iostream>
#include "Header.h"
int main() {
	int n;
	std::cin >> n;
	Fibonachi row;
	try {
		for (auto& it : row.GetFirstN(n))
			std::cout << it << std::endl;
	}
	catch (const std::invalid_argument& e) {
		std::cerr << "Invalid argument:" << e.what() << std::endl;
	}
	return 0;
}

