#include "Header.h"

bool Fibonachi::isValid(int n)
{
	return n > 0;
}

Fibonachi::Fibonachi()
{
}

std::vector<int> Fibonachi::GetFirstN(int n)
{
	std::vector<int> vec;
	if (isValid(n)) {
		vec.resize(n);
		vec[0] = 0;
		if (n > 1) {
			vec[1] = 1;
			for (int i = 2; i < n; i++) {
				vec[i] = vec[i - 1] + vec[i - 2];
			}
		}
	}
	else {
		throw std::invalid_argument("n is not a natural number!");
	}
	return vec;
}

