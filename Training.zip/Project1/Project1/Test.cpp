#include <gtest/gtest.h>
#include "Header.h"
TEST(FibonachiTest, Test1) {
    Fibonachi f;
    //for n = 5
    std::vector<int> expected = { 0, 1, 1, 2, 3 };
    std::vector<int> result = f.GetFirstN(5);
    EXPECT_EQ(result, expected);
}
TEST(FibonachiTest, Test2) {
    Fibonachi f;
    //for n = 3
    std::vector<int> expected = { 0, 1, 1 };
    std::vector<int> result = f.GetFirstN(3);
    EXPECT_EQ(result, expected);
}
TEST(FibonachiTest, Test3) {
    Fibonachi f;
    //for n = 10
    std::vector<int> expected = { 0, 1, 1, 2, 3, 5, 8, 13, 21, 34 };
    std::vector<int> result = f.GetFirstN(10);
    EXPECT_EQ(result, expected);
}
TEST(FibonachiTest, Test4) {
    Fibonachi f;
    //for n = 7
    std::vector<int> expected = { 0, 1, 1, 2, 3, 5, 8 };
    std::vector<int> result = f.GetFirstN(7);
    EXPECT_EQ(result, expected);
}
int main(int argc, char** argv) {
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}