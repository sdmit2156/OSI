#pragma once
#include <vector>
#include <stdexcept>
class Fibonachi {
private:
	bool isValid(int n);
public:
	Fibonachi();
	std::vector<int> GetFirstN(int n);
};
